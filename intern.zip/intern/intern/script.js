

function validateForm() {
    var form = document.forms[0];
    var fullName = form["full_name"].value;
    var email = form["email"].value;
    var dateOfBirth = form["date"].value;
    var contactNumber = form["contact_number"].value;
    var ratings = ["movies", "radio", "eat_out", "tv"];
    var currentYear = new Date().getFullYear();
    var birthYear = new Date(dateOfBirth).getFullYear();
    var age = currentYear - birthYear;

    if (!fullName || !email || !dateOfBirth || !contactNumber) {
        alert("All fields must be filled out");
        return false;
    }

    if (age < 5 || age > 120) {
        alert("Age must be between 5 and 120");
        return false;
    }

    for (var i = 0; i < ratings.length; i++) {
        var rating = form[ratings[i]].value;
        if (!rating) {
            alert("Please provide a rating for all questions");
            return false;
        }
    }

    return true;
}