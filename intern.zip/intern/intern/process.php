<?php
include('config.php');

// Retrieve form data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $date = $_POST['date'];
    $contact_number = $_POST['contact_number'];

    // Handle favorite food checkboxes
    $favorite_food = isset($_POST['favorite_food']) ? $_POST['favorite_food'] : [];
    if (!is_array($favorite_food)) {
        $favorite_food = [$favorite_food];
    }
    $favorite_food = implode(', ', $favorite_food);
//handle radio
    $movies = $_POST['movies'];
    $radio = $_POST['radio'];
    $eat_out = $_POST['eat_out'];
    $tv = $_POST['tv'];


    // Insert data into the database
    $sql= ("INSERT INTO surveys(full_name,email,date,contact_number,favorite_food,movies,radio,eat_out,tv) values('$full_name','$email','$date','$contact_number','$favorite_food','$movies','$radio','$eat_out','$tv')");
    $query = mysqli_query($conn,$sql);
    if(mysqli_query($conn,$sql)){
        echo "register_success";
        echo "<script> location.href='index.php'; </script>";
        exit;
}
}

?>
