
<?php
include('config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Survey Form</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap">
    <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
    <nav class="navigation" id="ui">
        <div class="logo">
           <h1>_Surveys</h1> 
        </div>
        <ul>
            <li><a href="index.php" class="menu-item" style="color: #00e0fd;">FILL OUT SURVEY</a></li>
            <li><a href="view_survey.php"class="menu-item">VIEW SURVEY RESULTS</a></li>
</ul>
    </nav>
    <section class="container">
        <div class="personal">
            <p>Personal Details:</p>
            <form method="post" action="process.php" onsubmit="return validateForm()">
                <label>Full Names</label>
                <input type="text" name="full_name" required>

                <label>Email</label>
                <input type="email" name="email" required>

                <label>Date of Birth</label>
                <input type="date" name="date" required>

                <label>Contact Number</label>
                <input type="tel" name="contact_number" required>
            </div>
                <div class="favor">
                    <p>What is your favorite food?</p>
                    <div class="food">
                    <input type="checkbox" id="pizza" name="favorite_food[]" value="Pizza">
                    <label for="pizza">Pizza</label>

                    <input type="checkbox" id="pasta" name="favorite_food[]" value="Pasta">
                    <label for="pasta">Pasta</label>

                    <input type="checkbox" id="pap_and_wors" name="favorite_food[]" value="Pap and Wors">
                    <label for="pap_and_wors">Pap and Wors</label>

                    <input type="checkbox" id="other" name="favorite_food[]" value="Other">
                    <label for="other">Other</label>
                </div>
            </div>
                <div class="scale">
                    <p>Please rate your level of agreement on the scale from 1 to 5, with 1 being "Strongly agree" and 5 being "Strongly disagree."</p>
                    <table class="table ">
                        <thead>
                            <tr>
                                <td></td>
                                <td>Strongly Agree</td>
                                <td>Agree</td>
                                <td>Neutral</td>
                                <td>Disagree</td>
                                <td>Strongly Disagree</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>I like to watch movies</td>
                                <td><input type="radio" name="movies" value="1" required></td>
                                <td><input type="radio" name="movies" value="2" required></td>
                                <td><input type="radio" name="movies" value="3" required></td>
                                <td><input type="radio" name="movies" value="4" required></td>
                                <td><input type="radio" name="movies" value="5" required></td>
                            </tr>
                            <tr>
                                <td>I like to listen to radio</td>
                                <td><input type="radio" name="radio" value="1" required></td>
                                <td><input type="radio" name="radio" value="2" required></td>
                                <td><input type="radio" name="radio" value="3" required></td>
                                <td><input type="radio" name="radio" value="4" required></td>
                                <td><input type="radio" name="radio" value="5" required></td>
                            </tr>
                            <tr>
                                <td>I like to eat out</td>
                                <td><input type="radio" name="eat_out" value="1" required></td>
                                <td><input type="radio" name="eat_out" value="2" required></td>
                                <td><input type="radio" name="eat_out" value="3" required></td>
                                <td><input type="radio" name="eat_out" value="4" required></td>
                                <td><input type="radio" name="eat_out" value="5" required></td>
                            </tr>
                            <tr>
                                <td>I like to watch TV</td>
                                <td><input type="radio" name="tv" value="1" required></td>
                                <td><input type="radio" name="tv" value="2" required></td>
                                <td><input type="radio" name="tv" value="3" required></td>
                                <td><input type="radio" name="tv" value="4" required></td>
                                <td><input type="radio" name="tv" value="5" required></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
               <center><button type="submit" class="submit">Submit</button></center>
            </form>
        </div>
    </section>
</body>
</html>

