<?php
include('config.php');

$total = "#surveys";
$average = "#average age";
$oldest = "#max age";
$youngest = "#min age";
$pizza_percentage = "# % pizza";
$pasta_percentage = "# % pasta";
$pap_wors_percentage = "# % pap and wors";
$movies = "#average of rating";
$radio = "#average of rating";
$eat_out = "#average of rating";
$tv = "#average of rating";

// Total number of surveys completed
$total_surveys = "SELECT COUNT(*) AS total FROM surveys";
$total_result = $conn->query($total_surveys);

if ($total_result && $total_result->num_rows > 0) {
    $total_count = $total_result->fetch_assoc()['total'];
    
    if ($total_count > 0) {
        $total = $total_count;

        // Average age of participants
        $average_age = "SELECT AVG(YEAR(CURDATE()) - YEAR(date)) AS average FROM surveys";
        $average_result = $conn->query($average_age);
        if ($average_result) {
            $average = round($average_result->fetch_assoc()['average'], 1);
        }

        // Oldest participant
        $oldest_person = "SELECT full_name, YEAR(CURDATE()) - YEAR(date) AS maxage FROM surveys ORDER BY date ASC LIMIT 1";
        $oldest_result = $conn->query($oldest_person);
        if ($oldest_result) {
            $oldest = $oldest_result->fetch_assoc()['maxage'];
        }

        // Youngest participant
        $youngest_person = "SELECT full_name, YEAR(CURDATE()) - YEAR(date) AS age FROM surveys ORDER BY date DESC LIMIT 1";
        $youngest_result = $conn->query($youngest_person);
        if ($youngest_result) {
            $youngest = $youngest_result->fetch_assoc()['age'];
        }

        // Percentage of people who like Pizza
        $pizza_lovers = "SELECT COUNT(*) AS pizza_lovers FROM surveys WHERE FIND_IN_SET('pizza', favorite_food)";
        $pizza_result = $conn->query($pizza_lovers);
        if ($pizza_result) {
            $pizza = $pizza_result->fetch_assoc()['pizza_lovers'];
            $pizza_percentage = round(($pizza / $total) * 100, 1);
        }

        // Percentage of people who like pasta
        $pasta_lovers = "SELECT COUNT(*) AS pasta_lovers FROM surveys WHERE FIND_IN_SET('pasta', favorite_food)";
        $pasta_result = $conn->query($pasta_lovers);
        if ($pasta_result) {
            $pasta = $pasta_result->fetch_assoc()['pasta_lovers'];
            $pasta_percentage = round(($pasta / $total) * 100, 1);
        }

        // Percentage of people who like pap and wors
        $pap_wors_lovers = "SELECT COUNT(*) AS pap_wors_lovers FROM surveys WHERE FIND_IN_SET('Pap and Wors', favorite_food)";
        $pap_wors_result = $conn->query($pap_wors_lovers);
        if ($pap_wors_result) {
            $pap_wors = $pap_wors_result->fetch_assoc()['pap_wors_lovers'];
            $pap_wors_percentage = round(($pap_wors / $total) * 100, 1);
        }

        // Average rating for people who like to watch movies
        $movies_average = "SELECT AVG(movies) AS average_movies FROM surveys";
        $movies_result = $conn->query($movies_average);
        if ($movies_result) {
            $movies = round($movies_result->fetch_assoc()['average_movies'], 1);
        }

        // Average rating for people who listen to radio
        $radio_average = "SELECT AVG(radio) AS average_radio FROM surveys";
        $radio_result = $conn->query($radio_average);
        if ($radio_result) {
            $radio = round($radio_result->fetch_assoc()['average_radio'], 1);
        }

        // Average rating for people who like to eat out
        $eat_out_average = "SELECT AVG(eat_out) AS average_eat_out FROM surveys";
        $eat_out_result = $conn->query($eat_out_average);
        if ($eat_out_result) {
            $eat_out = round($eat_out_result->fetch_assoc()['average_eat_out'], 1);
        }

        // Average rating for people who like to watch TV
        $tv_average = "SELECT AVG(tv) AS average_tv FROM surveys";
        $tv_result = $conn->query($tv_average);
        if ($tv_result) {
            $tv = round($tv_result->fetch_assoc()['average_tv'], 1);
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Survey Results</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap">
    <link rel="stylesheet" href="style.css">
    <style>
        .content {
            width: 50%;
            margin: 0 auto;
        }
        .flex-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .label {
            flex: 1;
        }
        .value {
            text-align: right;
        }
    </style>
</head>
<body>
    <nav class="navigation" id="ui">
        <div class="logo">
            <h1>_Surveys</h1>
        </div>
        <ul>
            <li><a href="index.php" class="menu-item">FILL OUT SURVEY</a></li>
            <li><a href="view_survey.php" class="menu-item" style="color: #00e0fd;">VIEW SURVEY RESULTS</a></li>
        </ul>
    </nav>
    <section class="view_container">
        <div class="result">
           <h1>Survey Results</h1>
        </div>
       
        <div class="content">
            <div class="flex-container">
                <p class="label">Total number of surveys:</p>
                <p class="value"><?php echo $total; ?></p>
            </div>
            <div class="flex-container">
                <p class="label">Average age:</p>
                <p class="value"><?php echo $average; ?></p>
            </div>
            <div class="flex-container">
                <p class="label">Oldest person who participated in survey:</p>
                <p class="value"><?php echo $oldest; ?></p>
            </div>
            <div class="flex-container">
                <p class="label">Youngest person who participated in survey:</p>
                <p class="value"><?php echo $youngest; ?></p>
            </div>
            <div class="flex-container">
                <p class="label">Percentage of people who like pizza:</p>
                <p class="value"><?php echo $pizza_percentage; ?>%</p>
            </div>
            <div class="flex-container">
                <p class="label">Percentage of people who like pasta:</p>
                <p class="value"><?php echo $pasta_percentage; ?>%</p>
            </div>
            <div class="flex-container">
                <p class="label">Percentage of people who like pap and wors:</p>
                <p class="value"><?php echo $pap_wors_percentage; ?>%</p>
            </div>
            <br>
            <div class="flex-container">
                <p class="label">People who like to watch movies:</p>
                <p class="value"><?php echo $movies; ?></p>
            </div>
            <div class="flex-container">
                <p class="label">People who like to listen to radio:</p>
                <p class="value"><?php echo $radio; ?></p>
            </div>
            <div class="flex-container">
                <p class="label">People who like to eat out:</p>
                <p class="value"><?php echo $eat_out; ?></p>
            </div>
            <div class="flex-container">
                <p class="label">People who like to watch TV:</p>
                <p class="value"><?php echo $tv; ?></p>
            </div>
        </div>
    </section>
</body>
</html>
